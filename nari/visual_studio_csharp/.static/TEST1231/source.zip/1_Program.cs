﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATIC_CSHARP_EXAMPLE
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("STATIC_C#_EXAMPLE!");
        }
    }
}
