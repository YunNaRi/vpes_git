#include <stdio.h>

int main() {
	int k = 1;
	int w=0;
	test();

	if (k < w) {
	
	}

	return 0;
}
int test() {
	int u = 1;
	int y = 0;
	int sum = 0;

	sum = u + y;
	printf_s("hello\r\n");

	return sum;
}
